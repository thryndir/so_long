/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lgalloux <lgalloux@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/12/18 19:29:39 by lgalloux          #+#    #+#             */
/*   Updated: 2023/12/21 11:53:03 by lgalloux         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

int	ft_count_line(int fd)
{
	static int j = 0;
	static size_t i = 0;
	t_map info;

	if (i == 0)
		while (get_next_line(fd))
			i++;
	j++;
	info.line_nbr = i;
	info.fd = fd;
	if (j == 1)
		return (j);
	ft_parsing(info);
	return(0);
}

char **ft_parsing(t_map info)
{
	size_t	j;

	info.map = malloc(info.line_nbr * sizeof(char *) + 1);
	if (!info.map)
		return (NULL);
	j = 0;
	while (j <= info.line_nbr)
		info.map[j++] = get_next_line(info.fd);
	info.line_len = ft_strlen(info.map[0]);
	reading_map(info);
	return(info.map);
}
